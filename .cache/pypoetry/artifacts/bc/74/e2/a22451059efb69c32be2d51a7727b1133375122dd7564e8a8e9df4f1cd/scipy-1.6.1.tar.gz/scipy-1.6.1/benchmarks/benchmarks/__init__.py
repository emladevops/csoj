import numpy as np
import random

np.random.seed(1234)
random.seed(1234)
