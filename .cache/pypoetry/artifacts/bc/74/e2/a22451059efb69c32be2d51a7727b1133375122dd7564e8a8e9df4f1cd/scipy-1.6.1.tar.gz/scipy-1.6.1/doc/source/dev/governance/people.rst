:orphan:

.. _governance-people:

Current steering council and institutional partners
===================================================

Benevolent Dictator for Life
----------------------------

Pauli Virtanen is the Benevolent Dictator for Life (BDFL)


Steering Council
----------------

* Anne Archibald
* Andrew Nelson
* Charles Harris
* Christoph Baumgarten
* CJ Carey
* Eric Larson
* Eric Moore
* Eric Quintero
* Evgeni Burovski
* Ilhan Polat
* Jaime Fernández del Río
* Josef Perktold
* Josh Wilson
* Matt Haberland
* Matthew Brett
* Nikolay Mayorov
* Paul van Mulbregt
* Pauli Virtanen
* Ralf Gommers (Chair)
* Tyler Reddy
* Warren Weckesser


Release Manager
---------------

Tyler Reddy is the current release manager


Institutional Partners
----------------------

None currently


Document history
----------------

https://github.com/scipy/scipy/commits/master/doc/source/dev/governance/people.rst
